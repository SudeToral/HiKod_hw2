import 'package:flutter/material.dart';
import 'dart:math';

class DetailsPage extends StatelessWidget {
  final String day;
  final List<String> tasks = [
    "Task 1","Task 2","Task 3"
  ];

  DetailsPage({required this.day});

  @override
  Widget build(BuildContext context) {
    List<String> dailytasks = [];

    for (int i = 0; i < tasks.length; i++){
     if (Random ().nextBool()) {
         dailytasks.add(tasks[i]);}}

    return Scaffold(
      appBar: AppBar(
        title: Text('Details Page'),
      ),
      body:
        Padding(
          padding: const EdgeInsets.all(14.0),
          child:
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text("Tasks for $day",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                for (String task in dailytasks)
                  Text(
                    task)
              ],
            )
        )



    );
  }
}


