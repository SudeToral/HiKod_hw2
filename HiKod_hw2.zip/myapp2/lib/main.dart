import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'details.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => NotificationProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  bool get isDarkMode => _isDarkMode;
  void toggleDarkMode() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }
}

class NotificationProvider with ChangeNotifier {
  bool _isNotificationEnabled = true;

  bool get isNotificationEnabled => _isNotificationEnabled;

  void toggleNotification() {
    _isNotificationEnabled = !_isNotificationEnabled;
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepOrange),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      darkTheme: ThemeData.dark().copyWith(
        primaryColor: Colors.deepPurple,
        hintColor: Colors.amber,
      ),
      home: const MyHomePage(title: 'HOME'),
    );
  }
}

class SecondPage extends StatefulWidget {
  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  String selectedOption = 'daily';

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: <Widget>[
          const SizedBox(
            width: 20,
            height:20,
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "THEME SETTINGS",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          SwitchListTile(
            title: const Text('Dark Mode'),
            value: themeProvider.isDarkMode,
            onChanged: (bool value) {
              themeProvider.toggleDarkMode();
            },
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "NOTIFICATION SETTINGS",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          SwitchListTile(
            title: const Text('Enable notifications',),
            value: Provider.of<NotificationProvider>(context).isNotificationEnabled,
            onChanged: (bool value) {
              Provider.of<NotificationProvider>(context, listen: false).toggleNotification();
            },
          ),
          Row(
            children: [
              const Text(
                'Selected Option:',
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(width: 10),
              DropdownButton<String>(
                value: selectedOption,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedOption = newValue!;
                  });
                },
                items: <String>['daily', 'weekly', 'monthly']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class PersonPage extends StatefulWidget {
  @override
  _PersonPageState createState() => _PersonPageState();
}

class _PersonPageState extends State<PersonPage> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Personal Info'),
      ),
      body: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'User Information',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          UserInfoItem(
            title: 'User Name',
            leading: Icon(Icons.person),
            value: 'John Doe',
          ),
          UserInfoItem(
            title: 'Email',
            leading: Icon(Icons.email),
            value: 'johndoe@example.com',
          ),
          UserInfoItem(
            title: 'Location',
            leading: Icon(Icons.location_on),
            value: 'New York, USA',
          ),
        ],
      ),
    );
  }
}

class UserInfoItem extends StatelessWidget {
  final Icon leading;
  final String title;
  final String value;

  const UserInfoItem({
    Key? key,
    required this.leading,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: leading,
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        value,
        style: TextStyle(
          fontSize: 14,
        ),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'HOME',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.person,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PersonPage()),
              );
            },
          ),
          IconButton(
            icon: const Icon(
              Icons.settings,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SecondPage()),
              );
            },
          ),
        ],
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Flexible(
            child: Column(
              children: <Widget>[
                Container(
                  height: 20.0,
                ),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'WELCOME TO MY SCHEDULE',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Image.network(
                  "https://tmetric.com/media/qfwptni2/work-schedules-header-banner.png",
                  width: 300,
                  height: 250,
                ),
                Container(
                  height: 60.0,
                  color: Colors.deepOrangeAccent,
                  child: const Center(
                    child: Text(
                      "SEE YOUR SCHEDULE FOR THIS WEEK",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 200,
                      child: ListView(
                        children: [
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('SUNDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Sunday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('MONDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Monday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('TUESDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>  DetailsPage(day: "Tuesday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('WEDNESDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Wednesday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('THURSDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Thursday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('FRIDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Friday"),
                                ),
                              );
                            },
                          ),
                          ListTile(
                            leading: const Icon(Icons.schedule),
                            title: const Text('SATURDAY'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailsPage(day: "Saturday"),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


